function detecttest() {
 if (document.cookie.indexOf("test_redirect=false") < 0) {
   if ((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPod/i))) {
    settestCookies();
    if (confirm("Kylie's new album 'Kiss Me Once' is out now!\n\nClick OK to open in iTunes."))
     window.location = "http://smarturl.it/kissmeonceD?IQid=iPhonePopup";
   } else if(navigator.userAgent.match(/iPad/i)) {
    settestCookies();
    if (confirm("Kylie's new album 'Kiss Me Once' is out now!\n\nClick OK to open in iTunes."))
     window.location = "http://smarturl.it/kissmeonceD?IQid=iPadPopup";
   } else if(navigator.userAgent.match(/Android/i)) {
    settestCookies();
    if (confirm("Kylie's new album 'Kiss Me Once' is out now!\n\nClick OK to open in the Google Play store."))
     window.location = "http://smarturl.it/KissMeOnceGPlay?IQid=AndroidPopup";
   }
 }
}
 
function settestCookies() {
 var date = new Date();
 var days = 1;
 date.setTime(date.getTime()+(days*24*60*60*1000));
 var expires = "; expires="+ date.toGMTString();
 document.cookie = "test_redirect=false" + expires + '; path=/'; 
}
 
detecttest();